#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 10;

    int *pnumber = &number; //pointer variable declare and initialize

    printf("Value of number:%d\n", *pnumber);

    printf("Address of number:%d", pnumber);

    return 0;
}
