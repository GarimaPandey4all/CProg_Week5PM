#include <stdio.h>
#include <stdlib.h>

int main()
{
    int count = 10, x;

    int *pcount = NULL;

    pcount = &count;

    x = *pcount;

    printf("Count is: %d and X is:%d", count, x);

    return 0;
}
