#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 20;

    int *pnumber = &number;

    *pnumber = 30; //re-initialize number indirectly by using pointer variable

    printf("Number is:%d", *pnumber);

    return 0;
}
