#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 99;

    int *pnumber = NULL;

    pnumber = &number;

    printf("Value of number is:%d", *pnumber);

    return 0;
}
