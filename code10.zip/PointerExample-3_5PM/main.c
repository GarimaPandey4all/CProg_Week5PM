#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 10;

    int *pnumber = &number;

    int result = 0;

    //result = *pnumber + 15;

    result = pnumber + 15;

    printf("Result is:%d", result);

    return 0;
}
