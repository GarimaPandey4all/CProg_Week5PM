#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 100;

    int *pnumber = NULL;

    pnumber = &number;

    *pnumber += 10; //*pnumber = *pnumber + 10; //*pnumber = 110;

    printf("Number is: %d", *pnumber);

    return 0;
}
