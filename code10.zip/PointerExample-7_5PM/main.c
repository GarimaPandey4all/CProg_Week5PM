#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 20;

    int *pnumber = &number;

    printf("Number is:%d\n", pnumber);

    printf("Number is:%p\n", pnumber);

    printf("Pnumber is:%d", sizeof(pnumber));

    return 0;
}
