#include <stdio.h>
#include <stdlib.h>

//Even-Odd Program

int main()
{
    int number, remainder;

    printf("Enter any number:");
    scanf("%d", &number);

    remainder = number % 2; //gives remainder //20%2= 0

    if(remainder == 0)
        printf("Number is Even.");
    else
        printf("Number is Odd.");

    //(remainder==0)? printf("Number is Even."):printf("Number is Odd");

    return 0;
}
