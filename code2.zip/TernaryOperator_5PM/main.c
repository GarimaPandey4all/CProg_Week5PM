#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, Largest;

    printf("Enter values for a and b:");
    scanf("%d %d", &a, &b);

    Largest = (a>b)? a : b;

    printf("Largest number is: %d", Largest);

    return 0;
}
