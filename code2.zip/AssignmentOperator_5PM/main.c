#include <stdio.h>
#include <stdlib.h>

int main()
{
    int marks[5]={89,90,78,88,80}, i, sum=0;

    for(i=0; i<5; i++)
    {
        sum += marks[i]; //sum = sum + marks[i];
    }

    printf("Total number of marks is: %d", sum);


    return 0;
}
