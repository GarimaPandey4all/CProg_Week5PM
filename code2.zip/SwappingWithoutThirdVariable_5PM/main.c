#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a=3, b=5;

    printf("Before swapping the value of a=%d and b=%d\n", a, b);


    // 1st Way: + and -

//    a = a + b; //a=8
//    b = a - b; //b=3
//    a = a - b; //a=5
//
//    printf("After swapping the value of a=%d and b=%d", a, b);
//

    // 2nd Way: * and /

//    a = a * b; //a=15
//    b = a / b; //b=3
//    a = a / b; //a=5
//
//    printf("After swapping the value of a=%d and b=%d", a, b);


    //3rd way: X-OR Operator

    a = a ^ b; //0011 ^ 0101 = 0110=6
    b = a ^ b; //0110 ^ 0101 = 0011=3
    a = a ^ b; //0110 ^ 0011 = 0101=5

    printf("After swapping the value of a=%d and b=%d", a, b);

    return 0;
}
