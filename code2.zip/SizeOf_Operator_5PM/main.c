#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    char ch;
    float f;
    double d;

    printf("Size of Int: %d\n", sizeof(int));
    printf("Size of Char: %d\n", sizeof(char));
    printf("Size of Float: %u\n", sizeof(float));
    printf("Size of Double: %u\n", sizeof(double));

    return 0;
}
