#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a=3, b=5;

    //3--> 0000 0011, 5--> 0000 0101

    //& Opeartor:

    printf("Bitwise & Operator:%d\n", (a&b));

    // | Opeartor:

    printf("Bitwise | Operator:%d\n", (a|b));

    // ~ Opeartor:

    printf("Bitwise ~ Operator:%d\n", ~b);

    // << Opeartor:

    printf("Bitwise << Operator:%d\n", a<<1);

    // >> Opeartor:

    printf("Bitwise >> Operator:%d\n", b>>1);

    // ^ Opeartor:

    printf("Bitwise ^ Operator:%d\n", (a^b));

    return 0;
}
