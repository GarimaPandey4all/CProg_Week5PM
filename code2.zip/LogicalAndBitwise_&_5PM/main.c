#include <stdio.h>
#include <stdlib.h>

int main()
{
    char x=1, y=2;

    //x--> 0000 0001, y--> 0000 0010

    if(x&y)
        printf("This is x&y.");

    if(x&&y)
        printf("This is x&&y.");

    return 0;
}
