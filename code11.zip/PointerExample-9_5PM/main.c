#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 10;

    int *pvalue = NULL;

    pvalue = &value;

    *pvalue = *pvalue + 40;

    printf("*pvalue is:%d", *pvalue);

    return 0;
}
