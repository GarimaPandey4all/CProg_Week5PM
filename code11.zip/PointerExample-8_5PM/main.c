#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 999;

    int *pvalue = NULL;

    pvalue = &value;

    printf("Value is:%d\n", *pvalue);

    int number = 400;

    pvalue = &number;

    printf("Number is:%d", *pvalue);

    return 0;
}
