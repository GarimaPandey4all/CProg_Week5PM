#include <stdio.h>
#include <stdlib.h>

int main()
{
    int marks[10]],i;

    printf("Enter values in an Array:");
    for(i=0; i<10; i++)
    scanf("%d", &marks[i]);

    printf("Values in Array are:");
    for(i=0; i<10; i++)
    printf("%d\t", marks[i]);


    return 0;
}
