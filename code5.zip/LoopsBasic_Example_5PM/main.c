/*

    for(initialization; condition; increment/decrement)
    {
            block of code
    }

    initialization
    while(condition)
    {
        increment/decrement
    }

    initialization
    do
    {
        increment/decrement
    }while(condition);

*/
