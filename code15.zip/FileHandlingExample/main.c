#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;

    int c;

      //fp = fopen("E:\\Training\\CPrograms\\FileHandlingExample\\bin\\Debug\\file1.txt","r");

      fp = fopen("file.txt","r"); //(filename, "r")

    if(fp == NULL)
    {
                perror("Error in Opening file");
                exit(0);
    }

    while((c = fgetc(fp)) != EOF)
                printf("%c", c);

            fclose(fp);
            fp = NULL;

            return (0);
}
