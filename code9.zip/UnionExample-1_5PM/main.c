#include <stdio.h>
#include <stdlib.h>

union Data
{
    int i;
    int c;
    int b;
}data;

//union Data data;

int main()
{
    data.i = 10;
    data.c = 50;
    data.b = 30;

    printf("I is:%d\n", data.i);
    printf("C is:%d \n", data.c);
    printf("B is:%d\n", data.b);

    return 0;
}
