#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int Day;
    int Month;
    int Year;
}date, date1, date2;



int main()
{
    date.Day = 2;
    date.Month = 3;
    date.Year = 2020;

    printf("Day is: %d\n", date.Day);
    printf("Month is: %d\n", date.Month);
    printf("Year is: %d", date.Year);


    return 0;
}
