#include <stdio.h>
#include <stdlib.h>

int main()
{
    enum Week {Monday, Tuesday=2, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week Today;

    Today = Monday;

    printf("Today is: %d", Today);

    return 0;
}
