#include <stdio.h>
#include <stdlib.h>

union Employee
{
    int id;
    int salary;
    int dept;
}Emp1;


int main()
{
    printf("Employee's Details:\n");

    Emp1.dept = 03;
    printf("Employee Department: %d\n", Emp1.dept);

    Emp1.id = 102;
    printf("Employee Id: %d\n", Emp1.id);

    Emp1.salary = 25000;
    printf("Employee Salary: %d\n", Emp1.salary);

    return 0;
}
