#include <stdio.h>
#include <stdlib.h>

struct Employee
{
    int id;
    int salary;
    int dept;
}Emp1;


int main()
{
    Emp1.dept = 03;
    Emp1.id = 102;
    Emp1.salary = 25000;

    printf("Employee's Details:\n");
    printf("Employee Department: %d\n", Emp1.dept);
    printf("Employee Id: %d\n", Emp1.id);
    printf("Employee Salary: %d\n", Emp1.salary);

    return 0;
}
