#include <stdio.h>
#include <stdlib.h>

int main()
{
    enum Gender {Male=1, Female};

    enum Gender mygender;

    mygender = Male;

    enum Gender mygender2;

    mygender2 = Female;

    printf("Male is:%d\n", mygender);

    printf("Female is:%d", mygender2);

    return 0;
}
