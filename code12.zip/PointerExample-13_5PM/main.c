#include <stdio.h>
#include <stdlib.h>

int main()
{
    //constant pointer //address can't be changed

    int value = 10;

    int number = 20;

    int *const pvalue = &value; //constant pointer

    *pvalue = 20; //okay

    value = 30; //okay

    //pvalue = &number; //error

    printf("Value is:%d", *pvalue);

    return 0;
}
