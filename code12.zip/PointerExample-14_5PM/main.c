#include <stdio.h>
#include <stdlib.h>

int main()
{
    //constant pointer //address can't be changed

    const int value = 10;

    const int number = 20;

    const int *const pvalue = &value; //constant pointer

//    *pvalue = 20; // error
//
//    pvalue = &number; //error
//
//    value = 20; //error

    printf("Value is:%d", *pvalue);

    return 0;
}
