#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10];
    int i;

    int *parray;

//    parray = &array[0];
//
//    or

    parray = array;

    printf("Enter values in an Array:");
    for(i=0; i<10; i++)
    {
        scanf("%d", parray + i); //pointer arithmetic
    }


    printf("Value in an Array are:");
    for(i=0; i<10; i++){
        printf("%d\t", *parray);
        ++parray;
    }


    return 0;
}
