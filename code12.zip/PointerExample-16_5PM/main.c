#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10]={10,20,30,40,50,60,70,80,90,100};
    int i;

    int *parray;

//    parray = &array[0];
//
//    or

    parray = array;

    printf("Value in an Array are:");
    for(i=0; i<10; i++){
        printf("%d\t", *parray);
        ++parray;
    }


    return 0;
}
