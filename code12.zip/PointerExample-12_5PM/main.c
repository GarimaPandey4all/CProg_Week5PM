#include <stdio.h>
#include <stdlib.h>

int main()
{
    //pointer to a constant //value can't be changed

    int value = 10;

    int number = 20;

    const int *pvalue = &value; //pointer to a constant

    //*pvalue = 20; //error

    number = 30; //okay

    pvalue = &number; //okay

    printf("Value is:%d", *pvalue);

    return 0;
}
