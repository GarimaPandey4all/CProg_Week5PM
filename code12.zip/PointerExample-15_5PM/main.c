#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 10;
    float j = 2.34f;
    char z = 'A';

    void *vptr;

    vptr = &i;
    printf("Is is:%d\n", *(int *)vptr);

    vptr = &j;
    printf("J is:%.2f\n", *(float *)vptr);

    vptr = &z;
    printf("Z is:%c", *(char *)vptr);

    return 0;
}
