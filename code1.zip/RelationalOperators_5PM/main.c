#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Relational Operators

    int a, b;

    printf("Enter value for a:");
    scanf("%d", &a);

    printf("Enter value for b:");
    scanf("%d", &b);

    if(a == b)
        printf("A is equal to B\n");

    if(a != b)
        printf("A is not equal to B\n");

    if(a >= b)
        printf("A is greater than B\n");

    if(a <= b)
        printf("A is less than B\n");

    return 0;
}
