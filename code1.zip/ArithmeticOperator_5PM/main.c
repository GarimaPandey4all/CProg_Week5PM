#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Arithmetic Operators

    int a, b;

    printf("Enter value for a:");
    scanf("%d", &a);

    printf("Enter value for b:");
    scanf("%d", &b);

    //c = a+b;

    printf("Subtraction is:%d\n", a-b);

    printf("Multiplication is:%d\n", a*b);

    printf("Division is:%d\n", a/b);

    printf("Modulus is:%d\n", a%b);

    //Pre and Post Increment

    printf("Pre-Increment is: %d\n", ++a); //a = 10

    printf("Post-Increment is: %d\n", a++);

    printf("A is: %d\n", a);

    //Pre and Post Decrement

    printf("Pre-Decrement is: %d\n", --b); //b = 8

    printf("Post-Decrement is: %d\n", b--);

    printf("B is: %d", b);

    return 0;
}
