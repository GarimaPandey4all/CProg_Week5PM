#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Assignment Operators

    int array[5], sum=0, i;

    printf("Enter values in an array:");

    for(i=0; i<5; i++)
    {
        scanf("%d", &array[i]);
    }

    for(i=0; i<5; i++)
    {
        //sum = sum + array[i];

        sum += array[i];
    }

    printf("Addition is: %d", sum);



    return 0;
}
