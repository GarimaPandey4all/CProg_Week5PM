#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Logical Operators

    int a, b;

    printf("Enter value for a:");
    scanf("%d", &a);

    printf("Enter value for b:");
    scanf("%d", &b);

    if(a && b)
        printf("This is A && B\n");

    if(a || b)
        printf("This is A || B\n");

    if(!(a && b))
        printf("This is !(A && B)\n");

    return 0;
}
