#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number, remainder, reverse=0;

    printf("Enter any number to find the reverse number:");
    scanf("%d", &number);

    while(number>0)
    {
        remainder = number % 10; //121 % 10 = 1 //2 //1

        reverse = reverse * 10 + remainder; // 121

        number = number / 10; // 121/10= 12 //1 //0

    }

    printf("Reverse number is: %d", reverse);

    return 0;
}
