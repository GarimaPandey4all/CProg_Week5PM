#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number, remainder, sum=0, temp;

    printf("Enter any number to check whether the number is Palindrome or not?");
    scanf("%d", &number);

    temp = number;

    while(number>0)
    {
        remainder = number % 10; //121 % 10 = 1 //2 //1

        sum = sum * 10 + remainder; // 121

        number = number / 10; // 121/10= 12 //1 //0

    }

    number = temp;

    if(number == sum)
    {
        printf("Number is Palindrome");
    }
    else
    {
        printf("Not a Palindrome Number");
    }

    return 0;
}
