#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number, remainder, sum=0;

    printf("Enter any number to find the reverse number:");
    scanf("%d", &number);

    while(number>0)
    {
        remainder = number % 10; //121 % 10 = 1 //2 //1

        sum = sum + remainder; // 1//3//4

        number = number / 10; // 121/10= 12 //1 //0

    }

    printf("Reverse number is: %d", sum);

    return 0;
}
