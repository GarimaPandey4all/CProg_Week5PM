#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int Day;
    int Month;
    int Year;
}date, *pdate;

//struct Date date, *pdate;

int main()
{
    pdate = &date;

    pdate->Day = 3;
    pdate->Month = 4;
    pdate->Year = 2020;

    printf("Day %d Month %d Year %d", pdate->Day, pdate->Month, pdate->Year);

    return 0;
}
