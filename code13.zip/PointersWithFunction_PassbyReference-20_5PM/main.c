#include <stdio.h>
#include <stdlib.h>

void Swap(int*, int*); //function declaration

int main()
{
    int a=10, b=20;

    printf("Before Swapping the value of a=%d and b=%d.\n", a, b);

    Swap(&a, &b); //function calling

    printf("After Swapping the value of a=%d and b=%d.", a, b);

    return 0;
}

void Swap(int *a, int *b) //function definition
{
    int temp;

    temp = *a;
    *a = *b;
    *b = temp;
}
