#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    char operator;

    printf("Please enter any Operator:");
    scanf("%c", &operator);

    switch(operator)
    {
    case '+':

        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Addition is:%d", a+b);
        break;


    case '-':
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Subtraction is:%d", a-b);
        break;

    case '*':
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Multiply is:%d", a*b);
        break;

    case '/':
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Division is:%d", a/b);
        break;

    case '%':
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Modulus is:%d", a%b);
        break;

    default:
        printf("You have entered the wrong operator.");
    }

    return 0;
}
