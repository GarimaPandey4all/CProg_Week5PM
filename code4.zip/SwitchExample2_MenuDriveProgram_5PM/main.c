#include <stdio.h>
#include <stdlib.h>

//Menu Driven Program

int main()
{
    int choice;
    int a, b, c, Largest,number;

    //for(;;)
    while(1) //infinite loop
    {
    printf("\n\nPress 1. for Addition.\n");
    printf("Press 2. for Largest Number.\n");
    printf("Press 3. for X-OR.\n");
    printf("Press 4. for Left Shift.\n");
    printf("Press 5. for Right Shift.\n");
    printf("Press 6. for Even-Odd.\n");
    printf("Press 7. for Exit.\n");
    printf("Enter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        printf("Enter any vale for a and b:");
        scanf("%d %d", &a, &b);

        printf("Addition is: %d", a+b);

        break;

    case 2:
        printf("Enter any vale for a, b and c:");
        scanf("%d %d %d", &a, &b, &c);

        Largest = (a>b)?((a>c)?a:c):((b>c)?b:c);

        printf("Largest Number is:%d", Largest);

        break;

    case 3:
        printf("Enter any vale for a and b:");
        scanf("%d %d", &a, &b);

        printf("X-OR is: %d", a^b);

        break;

    case 4:
        printf("Enter any vale for a:");
        scanf("%d", &a);

        printf("Left Shift is: %d", a<<1);

        break;

    case 5:

        printf("Enter any vale for b:");
        scanf("%d", &b);

        printf("Left Shift is: %d", b<<1);

        break;

    case 6:

        printf("Enter any Number");
        scanf("%d", &number);

        ((number%2)==0)?printf("Number is Even"):printf("Number is Odd");

        break;

    case 7:
        exit(0); //exit the program

    default:
        printf("You have entered the wrong case.");
    }
    }

    return 0;
}
